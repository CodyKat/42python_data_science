from distutils.core import setup

setup(
    name='ft_package',
    version='0.0.1',
    license='free',
    packages=['ft_package'],
    author='jaemjeon',
    author_email='jaemjeon@42student.42seoul.kr',
    description='just loading bar package'
)
